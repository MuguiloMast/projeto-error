package com.rev.revisao.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.rev.revisao.dto.TaskDTO;

@Service
public class TaskService {

    public List<TaskDTO> getAllTasks() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    // Métodos implementados:
    // - getAllTasks()
    // - getTaskById(Long id)
    // - createTask(TaskDTO taskDTO)
    // - updateTask(Long id, TaskDTO taskDTO)
    // - deleteTask(Long id)
    // - toggleTaskCompletion(Long id)

    public Optional<TaskDTO> getTaskById(Long id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public TaskDTO createTask(TaskDTO taskDTO) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean deleteTask(Long id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Optional<TaskDTO> updateTask(Long id, TaskDTO taskDTO) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Optional<TaskDTO> toggleTaskCompletion(long id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
