package com.rev.revisao.mapper;

import org.springframework.stereotype.Component;

import com.rev.revisao.dto.TaskDTO;
import com.rev.revisao.model.Task;

@Component
public class TaskMapper {
    public TaskDTO toDTO(Task task) {
        return null;
    }
    public Task toEntity(TaskDTO taskDTO) {
        return null;
    }
    public void updateEntityFromDTO(TaskDTO taskDTO, Task task) {
    }
}